# SabziKart - Minimal Vite React Starter (Supabase-ready)

## Quick start

1. Copy `.env.example` to `.env.local` and fill your Supabase URL + ANON KEY.
2. Install, run dev server:
   ```bash
   npm install
   npm run dev
   ```
3. Open `http://localhost:5173`

This project contains a simple Product Catalog, Checkout (COD/UPI), Admin Dashboard and Order Tracking integrated with Supabase (you must create tables as instructed in earlier conversation).
