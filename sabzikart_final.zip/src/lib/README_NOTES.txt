Supabase tables expected:

products(id serial PK, name text, price numeric, image_url text, stock int, category text, created_at timestamptz)
orders(id serial PK, customer_name text, phone text, address text, pincode text, slot text, total numeric, payment_method text, status text, created_at timestamptz)
order_items(id serial PK, order_id int references orders(id), product_id int references products(id), quantity int, price numeric)

Run the SQL provided in the conversation to create tables.
