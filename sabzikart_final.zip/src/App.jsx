import React, { useState } from 'react'
import ProductCatalog from './components/ProductCatalog'
import Checkout from './components/Checkout'
import AdminDashboard from './components/AdminDashboard'
import OrderTracking from './components/OrderTracking'

export default function App(){
  const [cart, setCart] = useState([])
  const [mode, setMode] = useState('user')

  const addToCart = (product) => {
    // add minimal qty logic
    const existing = cart.find(c => c.id === product.id)
    if(existing){
      setCart(cart.map(c => c.id === product.id ? { ...c, qty: c.qty + 1 } : c))
    } else {
      setCart([...cart, { ...product, qty: 1 }])
    }
  }
  const clearCart = () => setCart([])

  return (
    <div className="min-h-screen bg-[#fdfaf6] text-[#2c3e50] p-4">
      <header className="max-w-6xl mx-auto flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold flex items-center gap-2">🥕 SabziKart</h1>
        <nav className="flex gap-2">
          <button onClick={()=>setMode('user')} className={`px-3 py-1 rounded ${mode==='user' ? 'bg-green-600 text-white' : 'bg-white border'}`}>User</button>
          <button onClick={()=>setMode('admin')} className={`px-3 py-1 rounded ${mode==='admin' ? 'bg-purple-600 text-white' : 'bg-white border'}`}>Admin</button>
          <button onClick={()=>setMode('track')} className={`px-3 py-1 rounded ${mode==='track' ? 'bg-blue-600 text-white' : 'bg-white border'}`}>Track</button>
        </nav>
      </header>

      <main className="max-w-6xl mx-auto">
        {mode === 'admin' ? (
          <AdminDashboard />
        ) : mode === 'track' ? (
          <OrderTracking />
        ) : (
          <>
            <ProductCatalog addToCart={addToCart} />
            {cart.length > 0 && <Checkout cart={cart} clearCart={clearCart} />}
          </>
        )}
      </main>
    </div>
  )
}
