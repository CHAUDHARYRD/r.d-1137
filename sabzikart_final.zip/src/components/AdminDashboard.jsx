import React, { useEffect, useState } from 'react'
import { supabase } from '../lib/supabaseClient'

export default function AdminDashboard(){
  const [orders, setOrders] = useState([])
  const [filter, setFilter] = useState('ALL')

  async function fetchOrders(){
    let query = supabase.from('orders').select('id, customer_name, phone, address, pincode, slot, total, payment_method, status, created_at').order('created_at', { ascending:false })
    if(filter !== 'ALL') query = query.eq('payment_method', filter)
    const { data, error } = await query
    if(error) console.error(error)
    else setOrders(data || [])
  }

  useEffect(()=>{ fetchOrders() }, [filter])

  async function updateStatus(id, status){
    const { error } = await supabase.from('orders').update({ status }).eq('id', id)
    if(error) console.error(error)
    else fetchOrders()
  }

  return (
    <div className="bg-white p-4 rounded shadow">
      <h3 className="text-lg font-bold mb-2">Admin Orders</h3>
      <div className="mb-2">
        <select value={filter} onChange={e=>setFilter(e.target.value)} className="p-2 border">
          <option value="ALL">All</option>
          <option value="COD">COD</option>
          <option value="UPI">UPI</option>
        </select>
      </div>
      <div className="overflow-auto">
        <table className="w-full border-collapse">
          <thead className="bg-gray-100"><tr><th className="p-2 border">ID</th><th className="p-2 border">Customer</th><th className="p-2 border">Total</th><th className="p-2 border">Payment</th><th className="p-2 border">Status</th><th className="p-2 border">Action</th></tr></thead>
          <tbody>
            {orders.map(o=> (
              <tr key={o.id}><td className="p-2 border">{o.id}</td><td className="p-2 border">{o.customer_name}</td><td className="p-2 border">₹{o.total}</td><td className="p-2 border">{o.payment_method}</td><td className="p-2 border">{o.status}</td><td className="p-2 border"><select onChange={e=>updateStatus(o.id, e.target.value)} defaultValue=""><option value="">Set</option><option value="Paid">Paid</option><option value="Out for Delivery">Out for Delivery</option><option value="Delivered">Delivered</option><option value="Cancelled">Cancelled</option></select></td></tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
