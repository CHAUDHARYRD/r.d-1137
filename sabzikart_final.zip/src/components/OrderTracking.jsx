import React, { useState } from 'react'
import { supabase } from '../lib/supabaseClient'

export default function OrderTracking(){
  const [orderId, setOrderId] = useState('')
  const [order, setOrder] = useState(null)

  async function track(){
    const { data, error } = await supabase.from('orders').select('*').eq('id', orderId).maybeSingle()
    if(error || !data){ alert('Order not found'); setOrder(null) }
    else setOrder(data)
  }

  return (
    <div className="max-w-md mx-auto bg-white p-4 rounded shadow">
      <h3 className="text-lg font-bold mb-2">Track Order</h3>
      <input value={orderId} onChange={e=>setOrderId(e.target.value)} placeholder="Enter Order ID" className="w-full p-2 border mb-2"/>
      <button onClick={track} className="button w-full">Track</button>
      {order && <div className="mt-3 p-2 border rounded"><div><b>ID:</b> {order.id}</div><div><b>Status:</b> {order.status}</div><div><b>Total:</b> ₹{order.total}</div></div>}
    </div>
  )
}
