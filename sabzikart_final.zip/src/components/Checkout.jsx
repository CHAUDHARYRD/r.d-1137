import React, { useState } from 'react'
import { supabase } from '../lib/supabaseClient'

export default function Checkout({ cart, clearCart }){
  const [form, setForm] = useState({ name:'', phone:'', address:'', pin:'', payment_method: 'COD', slot: '8-11am' })
  const [loading, setLoading] = useState(false)
  const total = cart.reduce((s,i)=> s + (i.price||0) * (i.qty||1), 0)

  async function placeOrder(){
    if(!form.name || !form.phone || !form.address || !form.pin){ alert('Fill all fields'); return }
    setLoading(true)
    try{
      const { data, error } = await supabase.from('orders').insert([{
        customer_name: form.name,
        phone: form.phone,
        address: form.address,
        pincode: form.pin,
        slot: form.slot,
        payment_method: form.payment_method,
        total: total,
        status: form.payment_method === 'UPI' ? 'Pending' : 'Pending'
      }]).select().single()
      if(error) throw error
      const orderId = data.id
      // insert items
      const items = cart.map(i=> ({ order_id: orderId, product_id: i.id, quantity: i.qty, price: i.price }))
      const { error: itemsErr } = await supabase.from('order_items').insert(items)
      if(itemsErr) console.warn('order items error', itemsErr)
      // If UPI: open upi link (user will complete manually)
      if(form.payment_method === 'UPI'){
        const upi = encodeURIComponent(`upi://pay?pa=9624629190@ptsbi&pn=SabziKart&am=${total}&cu=INR`)
        window.location.href = `upi://pay?pa=9624629190@ptsbi&pn=SabziKart&am=${total}&cu=INR`
      }
      alert('Order placed. ID: ' + orderId)
      clearCart()
    }catch(err){
      console.error(err)
      alert('Order failed: ' + (err.message||JSON.stringify(err)))
    }finally{ setLoading(false) }
  }

  return (
    <div className="bg-white p-4 rounded shadow mt-6">
      <h3 className="text-lg font-bold mb-2">Checkout</h3>
      <input placeholder="Full name" value={form.name} onChange={e=>setForm({...form, name:e.target.value})} className="w-full p-2 border mb-2"/>
      <input placeholder="Phone" value={form.phone} onChange={e=>setForm({...form, phone:e.target.value})} className="w-full p-2 border mb-2"/>
      <textarea placeholder="Address" value={form.address} onChange={e=>setForm({...form, address:e.target.value})} className="w-full p-2 border mb-2"/>
      <input placeholder="Pincode" value={form.pin} onChange={e=>setForm({...form, pin:e.target.value})} className="w-full p-2 border mb-2"/>
      <select value={form.slot} onChange={e=>setForm({...form, slot:e.target.value})} className="w-full p-2 border mb-2">
        <option>8-11am</option>
        <option>11-2pm</option>
        <option>5-8pm</option>
      </select>
      <div className="mb-2">
        <label><input type="radio" checked={form.payment_method==='COD'} onChange={()=>setForm({...form, payment_method:'COD'})}/> Cash on Delivery</label>
        <label className="ml-4"><input type="radio" checked={form.payment_method==='UPI'} onChange={()=>setForm({...form, payment_method:'UPI'})}/> Pay via UPI</label>
      </div>
      <div className="flex justify-between items-center">
        <div className="font-semibold">Total: ₹{total}</div>
        <button onClick={placeOrder} disabled={loading} className="button">{loading? 'Placing...':'Place Order'}</button>
      </div>
    </div>
  )
}
