import React, { useEffect, useState } from 'react'
import { supabase } from '../lib/supabaseClient'

export default function ProductCatalog({ addToCart }) {
  const [products, setProducts] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(()=>{
    let mounted = true
    async function fetchProducts(){
      const { data, error } = await supabase.from('products').select('*').order('created_at', { ascending:false })
      if(error){ console.error(error); setProducts([]) }
      else if(mounted) setProducts(data || [])
      setLoading(false)
    }
    fetchProducts()
    return ()=> mounted = false
  },[])

  if(loading) return <p>Loading products...</p>

  return (
    <section className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
      {products.map(p => (
        <div key={p.id} className="bg-white p-4 rounded shadow">
          <img src={p.image_url || 'https://via.placeholder.com/200'} alt={p.name} className="w-full h-36 object-cover rounded mb-2"/>
          <div className="font-semibold">{p.name}</div>
          <div className="text-green-600 font-bold">₹{p.price}</div>
          <div className="text-sm text-gray-500">Stock: {p.stock}</div>
          <button disabled={p.stock<=0} onClick={()=>addToCart(p)} className="mt-2 button">{p.stock>0 ? 'Add to cart' : 'Out'}</button>
        </div>
      ))}
    </section>
  )
}
